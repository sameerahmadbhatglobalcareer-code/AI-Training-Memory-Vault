console.log("Memory Vault is actively monitoring the AI chat box.");

function injectMemoryVault() {
  // Target the exact editable elements across Gemini, ChatGPT, and Claude
  const chatInput = document.querySelector('div[id="prompt-textarea"], textarea, div[contenteditable="true"], p.is-empty');
  
  if (chatInput) {
    // If the element has already been processed or isn't empty, skip it
    if (chatInput.dataset.vaultActive || (chatInput.innerText && chatInput.innerText.trim() !== "")) {
      return;
    }

    chrome.storage.local.get({ savedNotes: [] }, function (data) {
      if (data.savedNotes && data.savedNotes.length > 0) {
        console.log("Found AI Input Box. Injecting your rules...");
        
        // Mark it as active so we don't loop endlessly
        chatInput.dataset.vaultActive = "true";

        // Build the payload cleanly
        let backgroundPayload = "\n\n[System Context Profile Activated]\n";
        data.savedNotes.forEach(note => {
            backgroundPayload += `- ${note.text}\n`;
        });

        // Focus the field to prepare for input
        chatInput.focus();

        // Handle standard textareas
        if (chatInput.tagName === "TEXTAREA") {
          chatInput.value = backgroundPayload;
        } 
        // Handle rich contenteditable divs (like Gemini & ChatGPT)
        else {
          // If it's a paragraph element inside the editor, use that, otherwise use the main element
          const targetNode = chatInput.tagName === "P" ? chatInput : (chatInput.querySelector('p') || chatInput);
          targetNode.innerText = backgroundPayload;
        }

        // CRITICAL STEP: Dispatch events to trick the website into acknowledging the text change
        const inputEvent = new Event('input', { bubbles: true, cancelable: true });
        chatInput.dispatchEvent(inputEvent);
        
        const changeEvent = new Event('change', { bubbles: true });
        chatInput.dispatchEvent(changeEvent);
      }
    });
  }
}

// Continuously scan every 2 seconds for fresh chat interfaces
setInterval(injectMemoryVault, 2000);