document.addEventListener('DOMContentLoaded', function () {
    loadSavedNotes();

    setupCopyButton('copyBtn1');
    setupCopyButton('copyBtn2');
    setupCopyButton('copyBtn3');

    const quickSaveBtn = document.getElementById('quickSaveBtn');
    if (quickSaveBtn) {
        quickSaveBtn.addEventListener('click', quickSave);
    }
});

function setupCopyButton(buttonId) {
    const btn = document.getElementById(buttonId);
    if (btn) {
        btn.addEventListener('click', function () {
            const targetId = btn.getAttribute('data-target');
            const textContent = document.getElementById(targetId).innerText;
            const fullPrompt = "The following is essential background context, project history, and rules for our task. Hold me accountable to these boundaries:\n\n" + textContent;            
            
            navigator.clipboard.writeText(fullPrompt).then(() => {
                const originalText = btn.innerText;
                btn.innerText = "✓ Copied!";
                btn.classList.add('copied');
                
                setTimeout(() => {
                    btn.innerText = originalText;
                    btn.classList.remove('copied');
                }, 2000);
            });
        });
    }
}

function quickSave() {
    const input = document.getElementById('quickThought');
    if (!input || !input.value.trim()) return;
    
    const textValue = input.value;
    const cardId = 'ctx_' + Date.now();
    
    chrome.storage.local.get({ savedNotes: [] }, function (data) {
        const notes = data.savedNotes;
        notes.push({ id: cardId, text: textValue });
        
        chrome.storage.local.set({ savedNotes: notes }, function () {
            renderNewCard(cardId, textValue);
            input.value = '';
        });
    });
}

function renderNewCard(cardId, text) {
    const grid = document.getElementById('vaultGrid');
    if (!grid) return;
    const newCard = document.createElement('div');
    newCard.className = 'card';
    newCard.innerHTML = `
        <div class="card-header">
            <h3 class="card-title">Quick Note</h3>
            <span class="tag personal">Personal</span>
        </div>
        <div class="card-body" id="${cardId}">${text}</div>
        <button class="copy-btn" id="btn_${cardId}">Copy formatted snippet</button>
    `;
    grid.insertBefore(newCard, grid.firstChild);

    const dynamicBtn = document.getElementById(`btn_${cardId}`);
    if (dynamicBtn) {
        dynamicBtn.addEventListener('click', function() {
            navigator.clipboard.writeText(text);
            dynamicBtn.innerText = "✓ Copied!";
            setTimeout(() => { dynamicBtn.innerText = "Copy formatted snippet"; }, 2000);
        });
    }
}

function loadSavedNotes() {
    chrome.storage.local.get({ savedNotes: [] }, function (data) {
        data.savedNotes.forEach(function (note) {
            renderNewCard(note.id, note.text);
        });
    });
}